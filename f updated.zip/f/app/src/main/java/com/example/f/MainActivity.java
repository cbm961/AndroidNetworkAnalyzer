package com.example.f;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.PackageManagerCompat;
import android.view.View;
import android.content.Intent;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.annotation.SuppressLint;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import java.security.Timestamp;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void GoPage1 (View view){
        Intent intent = new Intent(this, Page1.class);
        startActivity(intent);
    }

    public void GoPage2 (View view){
        Intent intent = new Intent(this, Page2.class);
        startActivity(intent);
    }
    }



