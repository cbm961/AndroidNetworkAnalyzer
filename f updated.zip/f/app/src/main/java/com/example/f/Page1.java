package com.example.f;

import androidx.appcompat.app.AppCompatActivity;

import static android.telephony.TelephonyManager.NETWORK_TYPE_1xRTT;
import static android.telephony.TelephonyManager.NETWORK_TYPE_CDMA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EDGE;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EHRPD;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EVDO_0;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EVDO_A;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EVDO_B;
import static android.telephony.TelephonyManager.NETWORK_TYPE_GPRS;
import static android.telephony.TelephonyManager.NETWORK_TYPE_GSM;
import static android.telephony.TelephonyManager.NETWORK_TYPE_HSDPA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_HSPA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_HSPAP;
import static android.telephony.TelephonyManager.NETWORK_TYPE_HSUPA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_IDEN;
import static android.telephony.TelephonyManager.NETWORK_TYPE_LTE;
import static android.telephony.TelephonyManager.NETWORK_TYPE_NR;
import static android.telephony.TelephonyManager.NETWORK_TYPE_TD_SCDMA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_UMTS;


import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.CellIdentityLte;
import android.telephony.CellInfo;
import android.telephony.CellInfoCdma;
import android.telephony.CellInfoGsm;
import android.telephony.CellInfoLte;
import android.telephony.CellSignalStrengthCdma;
import android.telephony.CellSignalStrengthGsm;
import android.telephony.CellSignalStrengthLte;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.annotation.SuppressLint;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import android.content.Intent;

public class Page1 extends AppCompatActivity {
    TextView OperatorName, NetworkType, CellID, SNR, SPower, FreqBand;
    TextView TStamp;
    int count=0;
    static final int PERMISSION_READ_STATE = 123;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page1);

        // Time Stamp
        TStamp = (TextView) findViewById(R.id.Tstamp);
        TStamp.setText(getCurrentTimestamp());

        // Operator Name
        OperatorName = (TextView) findViewById((R.id.OpName));
        OperatorName.setText(getOperatorName());

        //Network Type
        NetworkType = (TextView) findViewById((R.id.Ntype));
        NetworkType.setText(getNetworkType());

        //Cell ID
        CellID = (TextView) findViewById((R.id.CID));
        CellID.setText(GetCellID());

        //SNR
        SNR = (TextView) findViewById((R.id.SNR));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            SNR.setText(GetSNR() + "" + "(dB)");
        }
        //Signal Power
        SPower = (TextView) findViewById((R.id.Spower));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            SPower.setText(GetSignalP() + "" + "(dBm)");
        }
        //Frequency Band
        FreqBand=(TextView) findViewById(R.id.Fband);
        FreqBand.setText(GetFBand());


        //Repeat Every 5 Seconds
        content();


    }

    // Repeat Calls Every 5 Seconds.
    public void content(){
        count ++;
        refresh(5000); //refresh every 0.5 seconds
    }
    private void refresh(int ms){
        final Handler handler = new Handler();
        final Runnable runnable = new Runnable(){
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void run(){
                content();

                // Time Stamp
                TStamp = (TextView) findViewById(R.id.Tstamp);
                TStamp.setText(getCurrentTimestamp());

                // Operator Name
                OperatorName = (TextView) findViewById((R.id.OpName));
                OperatorName.setText(getOperatorName());

                //Network Type
                NetworkType = (TextView) findViewById((R.id.Ntype));
                NetworkType.setText(getNetworkType());

                //Cell ID
                CellID = (TextView) findViewById((R.id.CID));
                CellID.setText(GetCellID());

                //SNR
                SNR = (TextView) findViewById((R.id.SNR));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    SNR.setText(GetSNR() + "" + "(dB)");
                }
                //Signal Power
                SPower = (TextView) findViewById((R.id.Spower));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    SPower.setText(GetSignalP() + "" + "(dBm)");
                }

                //Frequency Band
                FreqBand=(TextView) findViewById(R.id.Fband);
                FreqBand.setText(GetFBand());
            }
        };
        handler.postDelayed(runnable, ms);
    }


    //Time Stamp
    @SuppressLint("SimpleDateFormat")
    public static String getCurrentTimestamp() {
        return new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(Calendar
                .getInstance().getTime());
    }

    //Operator Name
    public String getOperatorName() {
        Context context = this;
        TelephonyManager tm = ((TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE));
        String carriername = tm.getSimOperatorName();
        return carriername;
    }

    //Frequency Band
    public String GetFBand() {
        Context context = this;
        TelephonyManager tm = ((TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE));
        String FreqBand = tm.getNetworkCountryIso();
        return FreqBand;
    }


    //Network Type
    @RequiresApi(api = Build.VERSION_CODES.N)
    public String getNetworkType() {
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null || !info.isConnected())
            return ("N/A");
        if (info.getType() == ConnectivityManager.TYPE_WIFI)
            return ("WIFI");
        if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
            int networkType = info.getSubtype();
            switch (networkType) {
                case TelephonyManager.NETWORK_TYPE_GPRS:
                case TelephonyManager.NETWORK_TYPE_EDGE:
                case TelephonyManager.NETWORK_TYPE_CDMA:
                case TelephonyManager.NETWORK_TYPE_1xRTT:
                case TelephonyManager.NETWORK_TYPE_IDEN:
                case TelephonyManager.NETWORK_TYPE_GSM:
                    return ("2G");
                case TelephonyManager.NETWORK_TYPE_UMTS:
                case TelephonyManager.NETWORK_TYPE_EVDO_0:
                case TelephonyManager.NETWORK_TYPE_EVDO_A:
                case TelephonyManager.NETWORK_TYPE_HSDPA:
                case TelephonyManager.NETWORK_TYPE_HSUPA:
                case TelephonyManager.NETWORK_TYPE_HSPA:
                case TelephonyManager.NETWORK_TYPE_EVDO_B:
                case TelephonyManager.NETWORK_TYPE_EHRPD:
                case TelephonyManager.NETWORK_TYPE_HSPAP:
                case TelephonyManager.NETWORK_TYPE_TD_SCDMA:
                    return ("3G");
                case TelephonyManager.NETWORK_TYPE_LTE:
                case TelephonyManager.NETWORK_TYPE_IWLAN:
                case 19: // LTE_CA
                    return ("4G");
                case TelephonyManager.NETWORK_TYPE_NR:
                    return ("5G");
            }
        }
        return ("Unknown");
    }


    //Cell ID
    public String GetCellID() {
        GsmCellLocation cl;
        Context context = this;
        TelephonyManager tm = ((TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return "Permission Not Granted!";
        }
        cl = (GsmCellLocation) tm.getCellLocation();
        int ncid = cl.getCid() & 0xffff;
        return (Integer.toString(ncid));
    }

    //SNR
    @RequiresApi(api = Build.VERSION_CODES.O)
    public String GetSNR() {
        Context context = this;
        TelephonyManager tm = ((TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE));
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null || !info.isConnected())
            return ("N/A");
        if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
            int networkType = info.getSubtype();
            switch (networkType) {
                case TelephonyManager.NETWORK_TYPE_CDMA:
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                        return "Permission Not Granted!";
                    }
                    List<CellInfo> CI = tm.getAllCellInfo();
                    for (CellInfo information : CI) {
                        if (information instanceof CellInfoCdma) {
                            CellInfoCdma cellInfoCdma = (CellInfoCdma) information;
                            CellSignalStrengthCdma cellSignalStrengthCdma = (CellSignalStrengthCdma) cellInfoCdma.getCellSignalStrength();
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                int SNR = cellSignalStrengthCdma.getEvdoSnr();
                                return (Integer.toString(SNR));
                            }
                        }
                    }
                    return ("Not Available");
                case TelephonyManager.NETWORK_TYPE_LTE:
                case TelephonyManager.NETWORK_TYPE_IWLAN:
                case 19: // LTE_CA
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        return "Permission Not Granted!";
                    }
                    List<CellInfo> CInf = tm.getAllCellInfo();
                    for (CellInfo information : CInf) {
                        if (information instanceof CellInfoLte) {
                            CellInfoLte cellInfoLte = (CellInfoLte) information;
                            CellSignalStrengthLte cellSignalStrengthLte = (CellSignalStrengthLte) cellInfoLte.getCellSignalStrength();
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                int SNR = cellSignalStrengthLte.getRssnr();
                                return (Integer.toString(SNR));
                            }
                        }
                    }
                    return ("Not Available");
            }
        }
        return ("Unknown");
    }


    //Signal Power
    public String GetSignalP() {
        Context context = this;
        TelephonyManager tm = ((TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE));
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null || !info.isConnected())
            return ("N/A");
        if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
            int networkType = info.getSubtype();
            switch (networkType) {
                case TelephonyManager.NETWORK_TYPE_CDMA:
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                        return "Permission Not Granted!";
                    }
                    List<CellInfo> CI = tm.getAllCellInfo();
                    for (CellInfo information : CI) {
                        if (information instanceof CellInfoCdma) {
                            CellInfoCdma cellInfoCdma = (CellInfoCdma) information;
                            CellSignalStrengthCdma cellSignalStrengthCdma = (CellSignalStrengthCdma) cellInfoCdma.getCellSignalStrength();
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                int SP = cellSignalStrengthCdma.getDbm();
                                return (Integer.toString(SP));
                            }
                        }
                    }
                    return ("Not Available");


                case TelephonyManager.NETWORK_TYPE_GSM:
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                        return "Permission Not Granted!";
                    }
                    List<CellInfo> CInfo = tm.getAllCellInfo();
                    for (CellInfo information : CInfo) {
                        if (information instanceof CellInfoGsm) {
                            CellInfoGsm cellInfoGsm = (CellInfoGsm) information;
                            CellSignalStrengthGsm cellSignalStrengthGsm = (CellSignalStrengthGsm) cellInfoGsm.getCellSignalStrength();
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                int SP = cellSignalStrengthGsm.getDbm();
                                return (Integer.toString(SP));
                            }
                        }
                    }
                    return ("Not Available");


                case TelephonyManager.NETWORK_TYPE_LTE:
                case TelephonyManager.NETWORK_TYPE_IWLAN:
                case 19: // LTE_CA
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        return "Permission Not Granted!";
                    }
                    List<CellInfo> CInf = tm.getAllCellInfo();
                    for (CellInfo information : CInf) {
                        if (information instanceof CellInfoLte) {
                            CellInfoLte cellInfoLte = (CellInfoLte) information;
                            CellSignalStrengthLte cellSignalStrengthLte = (CellSignalStrengthLte) cellInfoLte.getCellSignalStrength();
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                int SP = cellSignalStrengthLte.getDbm();
                                return (Integer.toString(SP));
                            }
                        }
                    }
                    return ("Not Available");
            }
        }
        return ("Unknown");
    }





    public void GoHome1(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}






























